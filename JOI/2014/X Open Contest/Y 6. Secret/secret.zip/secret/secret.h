#ifndef SECRET_H_
#define SECRET_H_

void Init(int N, int A[]);
int Query(int L, int R);

int Secret(int X, int Y);

#endif  /* SECRET_H_ */
