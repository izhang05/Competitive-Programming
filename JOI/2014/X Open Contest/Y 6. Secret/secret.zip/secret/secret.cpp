#include "secret.h"

void Init(int N, int A[]) {
  Secret(0, 1000000000);
}

int Query(int L, int R) {
  return 0;
}
