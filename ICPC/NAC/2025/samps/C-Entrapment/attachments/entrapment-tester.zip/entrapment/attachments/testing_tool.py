#!/usr/bin/env python3

"""
Local testing tool for Entrapment.

Note: This tool is intended to help with debugging interaction.
It is *not* the same code used to test your solution when it
is submitted. For example, the tool makes random legal moves,
and does not attempt to stress-test your game strategy.

To run the testing tool, run::

    python3 testing_tool.py <filename> <program>

The following show examples for different languages:

    python3 testing_tool.py ell.in ./myprogram
    python3 testing_tool.py ell.in java -cp . MyProgram
    python3 testing_tool.py ell.in python3 myprogram.py

The first line of the file referenced in `filename` should contain two integers R and N,
the number of rounds that the game will last, and the number of grid cells initially marked
inaccessible, respectively. If N > 0, the next line of the file should contain a list of N
grid cell labels that are initially inaccessible. We have provided a couple of example
input files to test on.
"""

import argparse
import subprocess
import sys
import threading
from typing import TextIO

judge_program = './judge'

def vreadline(data: TextIO, char: str) -> str:
    """Read a line from `data`"""
    line = data.readline()
    if line:
        print(char, line.rstrip('\n'))
    return line
    
def judgeToUser(judge_process, user_process) -> int:
    while True:
        line = vreadline(judge_process.stdout, char='>')
        if not line:
            break
        try:        
            print(line, file=user_process.stdin, flush=True)
        except BrokenPipeError:
            print('ERROR: error when communicating with program - exited prematurely?')
            return 1
    print('(Judge exited)')        
    return 0
    
def userToJudge(judge_process, user_process) -> int:
    while True:
        line = vreadline(user_process.stdout, char='<')
        if not line:
            break
        print(line, file=judge_process.stdin, flush=True)
    print('(Your program exited)')
    judge_process.stdin.close()

def main() -> int:
    parser = argparse.ArgumentParser(usage='%(prog)s [-h] filename program [args...]')
    parser.add_argument('filename', type=str, help='filename containing input')
    parser.add_argument('program', nargs=argparse.REMAINDER)

    args = parser.parse_args()
    if not args.program:
        parser.error('Must specify program to run')

    if not args.filename:
        parser.error('Must specify test case filename')
        
    judge_process = subprocess.Popen([judge_program, args.filename], stdin=subprocess.PIPE, stdout=subprocess.PIPE, encoding='utf-8', errors='surrogateescape')
    user_process = subprocess.Popen(args.program, stdin=subprocess.PIPE, stdout=subprocess.PIPE, encoding='utf-8', errors='surrogateescape')
    
    t1 = threading.Thread(target=judgeToUser, args=(judge_process, user_process))
    t2 = threading.Thread(target=userToJudge, args=(judge_process, user_process))
    
    t1.start()
    t2.start()

    return 0

if __name__ == '__main__':
    sys.exit(main())
